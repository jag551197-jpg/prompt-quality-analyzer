# Validation Suite Inventory

| Layer | Executable Cases | Purpose |
|---|---:|---|
| L0_contract | 10 | Prove that every completed case returns the required final result fields. |
| L1_deterministic | 30 | Validate explicit rule/heuristic behavior without requiring semantic subtlety. |
| L2_judge | 20 | Validate semantic Gemini-as-judge behavior and structured output. |
| L3_pairwise | 80 | Validate relative ranking: engineered prompt B should outperform risky/underspecified prompt A. |
| L4_hallucination | 30 | Stress prompt-level hallucination-risk indicators and false-positive behavior. |
| L5_robustness | 30 | Adversarial, conflicting, missing-context, injection-like, and edge-case prompts. |
| L6_reliability | 0 | Operational validation of async submission/polling/persistence and result integrity. |
| L7_regression | 0 | Golden regression set to run on every release. |

**Total executable semantic/contract cases:** 200