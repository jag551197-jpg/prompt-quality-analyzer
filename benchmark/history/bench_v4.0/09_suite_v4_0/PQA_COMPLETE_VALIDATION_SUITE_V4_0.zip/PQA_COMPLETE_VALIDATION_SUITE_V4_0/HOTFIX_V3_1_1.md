# v3.1.1 Hotfix

Fixes a CLI/reporting bug where using an output path such as:

```bash
--out validation-results/L0_contract_RESULTS.md
```

failed if the parent directory did not already exist.

The runner now creates parent directories automatically before writing reports.

You may still create it manually with:

```bash
mkdir -p validation-results
```

but this is no longer required.
