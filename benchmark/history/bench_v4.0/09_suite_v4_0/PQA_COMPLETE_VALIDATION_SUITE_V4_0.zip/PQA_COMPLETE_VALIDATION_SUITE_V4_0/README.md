# PQA Complete Validation Suite v4.0

For **Prompt Quality Analyzer v1.5.0+**.

This bundle contains the complete 200-case validation suite and the v4 runner. The runner now reports real pairwise ranking accuracy and does not count cases with zero expectation checks as expectation passes.

## Run order
1. L0 contract
2. L1 deterministic
3. L2 Gemini judge
4. L3 pairwise
5. L4 hallucination
6. L5 robustness

## Start clean
```bash
rm -f *.checkpoint.json
export PQA_API_TOKEN='YOUR_TOKEN'
chmod +x pqa_benchmark_resilient.py run_all_validation.sh
./run_all_validation.sh
```

## Gates
- Result integrity: 100%
- L1 deterministic target: >=95%
- L2 semantic judge target: >=85% after calibration
- L3 pairwise ranking: >=95%
- L4 hallucination classification: >=90%
- L5 robustness: >=85%
