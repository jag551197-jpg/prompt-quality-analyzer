#!/usr/bin/env bash
set -euo pipefail
URL="${PQA_BASE_URL:-https://dainty-croissant-88f7f5.netlify.app}"
RUNNER="${PQA_RUNNER:-./pqa_benchmark_resilient.py}"
OUTDIR="${PQA_RESULTS_DIR:-./validation-results}"
mkdir -p "$OUTDIR"
if [[ -z "${PQA_API_TOKEN:-}" ]]; then
  echo "ERROR: export PQA_API_TOKEN='YOUR_TOKEN'"
  exit 3
fi
chmod +x "$RUNNER"
for f in L0_contract L1_deterministic L2_judge L3_pairwise L4_hallucination L5_robustness; do
  echo "=== Running $f ==="
  "$RUNNER" "${f}.json"     --url "$URL"     --batch-size 5     --poll 2     --batch-timeout 1800     --out "$OUTDIR/${f}_RESULTS.md" || true
done
echo "Validation layer runs complete. Review $OUTDIR."
