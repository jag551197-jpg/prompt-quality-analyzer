# PQA Complete Validation Suite v3

## Purpose
This suite separates result-contract integrity, deterministic-rule behavior, Gemini judge behavior, pairwise discrimination, hallucination-risk detection, robustness/adversarial behavior, operational reliability, and release regression.

## Layers
- **L0 Contract (10):** Required final fields and result integrity.
- **L1 Deterministic (30):** Explicit rule/heuristic triggers.
- **L2 Judge (20):** Semantic Gemini-as-judge behavior.
- **L3 Pairwise (80 / 40 pairs):** Strong prompt must outrank matched weak/risky variant.
- **L4 Hallucination (30):** Prompt-level hallucination-risk discrimination.
- **L5 Robustness (30):** Conflicts, missing context, adversarial/judge-injection-like prompts, schema and safety edge cases.
- **L6 Reliability protocol:** Repeat selected cases 100 times and measure async/poll/result integrity.
- **L7 Regression:** 50-case golden release gate.

## Immediate validity gates
Do not accept a layer as valid if a case is marked completed but lacks required final fields.
For all semantically evaluated cases require:
1. terminal case status
2. numeric overall score
3. hallucination risk value
4. structured recommendations array
5. final result payload
6. expectation evaluation when assertions are defined

## Recommended execution
Run L0 first. If L0 has missing fields, stop and fix transport/result contract.
Then run L1 and L2.
Only then run L3-L5.
Run L6 after semantic correctness is established.
Use L7 on every release.

## Public benchmark metrics
Publish:
- result-integrity rate
- expectation pass rate
- pairwise ranking accuracy
- hallucination-risk recall / false-positive rate
- human/PQA agreement
- repeated-run score variance
- terminal completion rate
- non-null result rate
- p50/p95 latency
- retry/timeout rate
- known failure cases and limitations
