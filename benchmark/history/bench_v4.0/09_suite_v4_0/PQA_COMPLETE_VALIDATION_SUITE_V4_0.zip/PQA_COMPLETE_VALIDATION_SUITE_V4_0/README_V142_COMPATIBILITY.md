# PQA Complete Validation Suite v3.1

This bundle is intended for Prompt Quality Analyzer **v1.4.2 or later**.

## Critical prerequisite

Verify:

```bash
curl https://your-site.netlify.app/api/health
```

and confirm the API reports:

```json
{
  "version": "1.4.2"
}
```

## Clear stale checkpoints before the first run

Old checkpoint files produced against earlier schemas can preserve invalid result shapes.

```bash
rm -f *.checkpoint.json
```

## Recommended execution order

1. `L0_contract.json`
2. `L1_deterministic.json`
3. `L2_judge.json`
4. `L3_pairwise.json`
5. `L4_hallucination.json`
6. `L5_robustness.json`

Do not continue past L0 unless result integrity is 100%.

## L0 acceptance gate

Required:
- all cases returned
- all cases have terminal status
- all cases have numeric score
- all cases have hallucination-risk value
- invalid result count = 0
- result integrity rate = 100%

## Run everything

```bash
export PQA_API_TOKEN='YOUR_TOKEN'
chmod +x run_all_validation.sh
./run_all_validation.sh
```

## Run only L0 first

```bash
export PQA_API_TOKEN='YOUR_TOKEN'

./pqa_benchmark_resilient.py   L0_contract.json   --url https://dainty-croissant-88f7f5.netlify.app   --batch-size 5   --poll 2   --out L0_contract_RESULTS.md
```
